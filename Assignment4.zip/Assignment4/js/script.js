// Practice with JavaScript OOP Concepts

////1.	Create a namespace called Animal. Then, define two sub namespaces, one called Cat and another called Dog.
//var Animal = Animal || {
//};
//Animal.Cat = Animal.Cat || {
//};
//Animal.Dog = Animal.Dog || {
//};

////2.	Abandon the use of namespaces and start over. Now, create two classes, one called Cat and another called Dog. The Cat class should be created using literal syntax and the Dog class should be created using the constructor syntax.

//var Cat = {
//};
//function Dog() {
//}

////3.	Create a new instance of Cat class. Directly underneath, create a new instance of the Dog class.

//var kitten = new Cat();
//var puppy = new Dog();


////4.	Start over and now create a new class using literal syntax called Animal. When a new instance of the Animal class is created, the message “The Animal has been created” should be displayed in the console window. 


//function Animal() {
//    window.console.log("The Animal has been created"); 
//}
//var animalNew = new Animal();


////5.	Now, change the above code so that is mimics a true constructor. The class should accept an argument and that value is what should be displayed in the console window. The message should be passed into the constructor at the moment that the Animal class is instantiated.


//function Animal(message) {
//    window.console.log(message); 
//}
//var animalNew = new Animal("The Animal has been created");

////6.	Start over and now create a new class using literal syntax called Animal. Define five properties within your class including properties type, breed, color, height, and length. These properties will be set in the constructor so you’ll need to pass in arguments into the function’s constructor, set the properties, and then pass in the actual values during the object’s instantiation.


//function Animal(type, breed, color, height, length) {
//    'use strict';
//    this.type = type;
//    this.breed = breed;
//    this.color = color;
//    this.height = height;
//    this.length = length;
//}
//var animal1 = new Animal("Dog", "Minituare Pointer", "Black", 4, 5);
//log(beast);


////7.	Use a for-in loop to loop through and display all of the properties in the Animal class. You should see a total of 5 properties displayed in a list within the console window.


//function Animal(type, breed, color, height, length) {
//    'use strict';
//    this.type = type;
//    this.breed = breed;
//    this.color = color;
//    this.height = height;
//    this.length = length;
//}
//var animal1 = new Animal("Dog", "Minituare Pointer", "Black", 4, 5),
//    //for (var property in animal1) {
//    window.console.log(property);
//    }
//}


////8.	Now, create a public method called speak. Within the speak method you will use a conditional to check the type of Animal being created. If it’s a dog, return “The <color> dog is barking!” If it’s a cat return “The <color> cat is meowing!” instead. Call that method after the Animal class has been instantiated.


//var Animal = function(type, breed, color, height, length) {
//    this._type = type;
//    this._breed = breed;
//    this._color = color;
//    this._height = height;
//    this._length = length;
//}
//    
//Animal.prototype.speak = function() {


//        if (this._type == "Dog") {

//            window.console.log("The " + this._color + " dog is barking");
//        } else if (this._type == "Cat") {
//            window.console.log("The " + this._color + " cat is meowing");
//        } else {
//            window.console.log("Does Not Compute, Danger Will Robinson!");
//        }
//    }
//
//var animal1 = new Animal("Dog", "Beagle", "Brown", "17 inches", "30 inches");
//animal1.speak();



////9.	Now, convert all of your properties to private properties. Then, create a private method called checkType(). In this method you will check to see what the type is. If it’s dog, return dog, otherwise, return cat. Then, create a public method called speak that returns the value of the checkType() method. The console window should now display “The <animal type> has made a noise!”


//var Animal = function(type, breed, color, height, length) {
//    var _type = type;
//    var _breed = breed;
//    var _color = color;
//    var _height = height;
//    var _length = length;
//    var checkType = function() {
//        if (_type == "Dog") {
//            return "dog";
////            window.console.log(_type);
//        } else  {
//            return "cat";
////            window.console.log("Cat");
//        } 
//    }
//    this.showAnimalInfo = function() {
//        checkType();
//    }
//    Animal.prototype.speak = function() {
//        window.console.log(checkType);
//        }
//}
//
//var animal1 = new Animal("Dog", "Minituare Pointer", "Brown", "17", "30");
//animal1.showAnimalInfo();
//animal1.speak();


////10.	Create your own String method called findWords that inherits from the native String Object. This method should find all instances of a specific word within a provided paragraph of text. It should then alert out to the user the number of time that word was found in the paragraph.


//String.prototype.findWords = function() {
//    var findWords = "";
//
//    
//    window.console.log("The word      \all\" is found " +                 message.match(/from/gi).length +      " times in the message");
    //return findWords;
//}
//var message = "After studying pretty much a little bit of everything, I am a jack of all trades. I am a scientists, a wine expert, a craft beer expert, and best of all a comedian! This all comes from the way I grew up in San Diego";
//
//message.findWords();


//==========================================================================

// Does My Vehicle Need AN Oil Change?

//// 11.	Create an abstract base class called Vehicle that accepts four parameters including make (string), model (string), total miles (number), and the mileage for the last oil change (number).

//var Vehicle = function(make, model, totalMiles, lastOilChange) {
//    
//}

//// 12.	Within the Vehicle class, create 6 public properties named make, model, totalMiles, drivenMiles, type, and lastOilChange. Initialize the make, model, totalMiles, and lastOilChange properties with their respective arguments. The drivenMiles property should be initialized to 0 and the type property should be initialized to an empty string.

//var Vehicle = function(make, model, totalMiles, lastOilChange) {
//    this.type = "";
//    this.make = make;
//    this.model = model;
//    this.totalMiles = 0;
//    this.lastOilChange = 0;
//    this.drivenMiles = 0;
//}


//// 13.	Now create a public method called drive() that accepts a parameter (perhaps miles). Increment and set the public drivenMiles property to the miles argument. Return the method (return this).

//Vehicle.prototype.drive = function(miles) {
//    this.drivenMiles += Number(miles);
//    alert("line 175 " + this.drivenMiles);
//    return this;
//    
//}


//// 14.	Now create a public method called checkOil(). Within this method, check to see if the total miles minus the last oil change plus the driven miles are greater than or equal to 3000. If they are, return a message to the user that they need an oil change. Otherwise, return the method (return this).

//Vehicle.prototype.checkOil = function() {
////    this.drivenMiles = this.totalMiles - this.lastOilChange;
//    alert("Line 185 " + this.drivenMiles);
//    if ((this.drivenMiles) >= 3000) {
//        window.console.log("You need an oil change");
//    } else {
//        return this;
//    }
//}


//// 15.	Now create a new sub class called Car that accepts one parameter for the amount of doors that the car has. 

//var Car = function(doorCount) {
//    
//}


//// 16.	Within the new Car class, initialize a public property called doorCount and set it equal to the argument.

//var Car = function(doorCount) {
//    this.doorCount = doorCount;
//}


//// 17.	Within the Car class use a conditional to check and see if the door count is greater than 2. If it is, set the type property to Sedan. Otherwise, set it to coupe.

//var Car = function(doorCount) {
//    this.doorCount = doorCount;
//    if (this.doorCount > 2) {
//        this.type = "Sedan";
//    } else {
//        this.type = "Coupe";
//    }
//}


//// 18.	Now, make sure that the Car class inherits from the Vehicle base class. Use this opportunity to pass in the make, model, total miles, and last oil change values into the Vehicle’s constructor. 

//Car.prototype = new Vehicle("Toyota", "Sienna", 90000, 100000);


//// 19.	Then, create a new instance of the Car class and pass in the number of doors that the car has into the Car’s constructor.

//var myCar = new Car(4);


//// 20.	Finally, using method chaining, call the drive() method of the car object, passing in a numeric value as a parameter. At the same time, call the checkOil() method. Display the results in the console window. You will either get a message indicating your car needs an oil change or you will get the object hierarchy.

//console.log(myCar.drive(100000).checkOil());



//=============================================================================

//  The Recipe Card


//Create an object to hold information on your favorite recipe. It should have properties for title (a string), servings (a number), and ingredients (an array of strings). Your object should have a publically available method that when called, will log out the recipe within the console so that the recipe information looks like this:
//Guacamole
//Serves: 4
//Ingredients: 
//- 3 Avocados
//- 1 Lime
//- 1 Teaspoon Salt
//- 1/2 Cup Onion
//- 3 Tablespoons Cilantro
//- 2 Diced Tomatoes
//- 1 Teaspoon Garlic
//- 1 Pinch Ground Pepper



//var recipe = {
//    "title": "Top Ramen",
//    "servings": 1,
//    "ingredients": ["2 Cups of water", "1 package of Top Ramen"],
//    "description": "Bring the 2 cups of water to a boil. Add 1 package of Top Ramen into boiling water. Add seasonings in the Top Ramen package. Wait until noodles are soft and enjoy!"
//};
//
//window.console.log(recipe.title);
//window.console.log("Servings: " + recipe.servings + "\n\n");
//window.console.log("Ingredients:\n\n");
//var i;
//for (i = 0; i < recipe.ingredients.length; i++) {
//    window.console.log(recipe.ingredients[i]);
//}
//
//window.console.log("\nDirections: \n" + recipe.description);


//=======================================================================


//   The Reading List  

//var books = [
//    {   title: "Homeland",
//        author: "R A Salvatore",
//        alreadyRead: true
//    },
//    {   title: "Exile",
//        author: "R A Salvatore",
//        alreadyRead: true
//    },
//    {   title: "Sojurn",
//        author: "R A Salvatore",
//        alreadyRead: true
//    },
//    {   title: "Neuromancer",
//        author: "William Gibson",
//        alreadyRead: false
//  },
//    {   title: "Fahrenheit 451",
//        author: "Ray Bradbury",
//        alreadyRead: true
//    },
//    {   title: "The Hunger Games",
//        author: "Suzanne Collins",
//        alreadyRead: false
//  }];
//
//for (var i = 0; i < books.length; i++) {

//  var book = books[i];
//  var bookInfo = book.title + " by " + book.author;
//  if (book.alreadyRead) {
//    console.log("You already read " + bookInfo);
//  } else {
//    console.log("You still need to read " + bookInfo);
//  }
//}


//================================================================================================================================

// Fill in the Blanks

// Fill in the blanks to make this program work.



//(function() {
//    var person = {
//        buy1: function() { window.console.log("I'm rich, I drive a Ferrari!"); },
//        buy2: function() { window.console.log("I got a job, I'm not poor, I drive a Honda Accord");},
//        buy3: function() { window.console.log("I'm poor, I drive a VW Beetle with duct tape"); }
//    };
//
//    var car = {
//        drive: function() { window.console.log("Vroom Vroom"); },
//        price: 199999
//    };
//
//    // print vroom vroom
//    car.drive();
//
//    // print 'I'm rich'
//    if (car.price > 100000) {
//        person.buy1(car);
//    } else if (car.price <= 100000 && car.price >= 30000) {
//        person.buy2(car);
//    } else {
//        person.buy3(car);
//    }
//}());
